Các bước để chạy chương trình
I. Server
	1. Nhập địa chỉ mạng lan
	2. Chọn file câu hỏi
	3. Nhấn "Chơi game"
	4. Chờ client chơi trả lời và bấm "Câu hỏi kế tiếp"
II. Client
	1. Nhập địa chỉ mạng lan
	2. Chờ server start thì trả lời câu hỏi`
